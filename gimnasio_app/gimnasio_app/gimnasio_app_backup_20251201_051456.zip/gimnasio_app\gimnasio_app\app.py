from flask import Flask, jsonify, request, render_template, redirect, url_for, flash, session, send_file
from flask_cors import CORS
import pymysql
import os
import uuid
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta, date
from functools import wraps
import random
import string
from urllib.parse import urljoin
import urllib.parse
try:
    from PIL import Image, ImageDraw, ImageFont
except Exception:
    Image = None
    ImageDraw = None
    ImageFont = None

app = Flask(__name__)
import os
import os
import uuid
from werkzeug.utils import secure_filename
from flask import url_for, flash, redirect, render_template, request
from conexion import obtener_conexion




# --- Configuración de uploads (pegar después de crear app = Flask(...)) ---
ALLOWED_EXT = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
UPLOAD_FOLDER = os.path.join('static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB máximo
# -------------------------------------------------------------------------

# Carpeta donde se guardarán las fotos
UPLOAD_FOLDER = os.path.join('static', 'uploads')
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
   
   
app.secret_key = 'gimnasio_secret_key'
CORS(app)

# === Formato y sanitización de moneda COP ===
def parse_cop(value):
    s = str(value or '').strip()
    # Remover prefijos y símbolos
    s = s.replace('COP', '').replace('cop', '').replace('$', '')
    # Quitar espacios y separadores de miles
    s = s.replace(' ', '').replace('.', '')
    # Usar punto como separador decimal
    s = s.replace(',', '.')
    try:
        return float(s)
    except Exception:
        return 0.0

def format_cop(value):
    try:
        n = float(value or 0)
    except Exception:
        n = 0
    # Formatear con separador de miles como punto y sin decimales
    formatted = '{:,.0f}'.format(n).replace(',', '.')
    return f'COP ${formatted}'

# Registrar filtro para usar en Jinja: {{ monto|cop }}
app.jinja_env.filters['cop'] = format_cop

# Configuración de uploads
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Carpeta para imágenes de facturas
FACTURAS_FOLDER = os.path.join('static', 'uploads', 'facturas')
os.makedirs(FACTURAS_FOLDER, exist_ok=True)

# Utilidad para construir URL pública absoluta (evita 127.0.0.1)
def build_public_url(path):
    base = os.environ.get('SHARE_BASE_URL') or request.url_root
    return urljoin(base, path.lstrip('/'))

# Generadores aleatorios para NIT y resolución DIAN
def generar_nit():
    return f"{random.randint(100000000, 999999999)}-{random.randint(0,9)}"

def generar_resolucion_dian():
    return f"{random.randint(10000000, 99999999)}/{random.randint(1000, 9999)}"

# Crear imagen tipo ticket de la factura (estilo POS)
def crear_imagen_factura(datos, destino):
    if Image is None:
        # Si PIL no está disponible, no generamos imagen
        return None
    width = 600
    base_h = 360
    items_h = 32 * max(len(datos.get('items', [])), 1)
    height = base_h + items_h + 140
    img = Image.new('RGB', (width, height), color='white')
    draw = ImageDraw.Draw(img)
    font = ImageFont.load_default()

    y = 18
    def line(text, x=20, inc=20):
        nonlocal y
        draw.text((x, y), str(text), fill=(0,0,0), font=font)
        y += inc

    # Encabezado
    line('GIMNASIO KOMDES WORD', x=180, inc=22)
    line(datos.get('nit', 'NIT: N/D'), x=200)
    line(f"Dirección: {datos.get('empresa_dir','Calle 18 #19c-133')}", x=160)
    line(f"Resolución DIAN {datos.get('dian','N/D')}", x=160)
    line(f"Autorizada el: {datos.get('fecha','')}", x=180)
    line("Prefijo POS Del: 1 Al: 1000000", x=160)
    line("Responsable de IVA", x=220)

    # Separador
    draw.line([(20, y+4), (width-20, y+4)], fill=(0,0,0), width=2)
    y += 12

    # Datos de factura
    line(f"Factura de venta: {datos.get('factura_numero','')} ")
    line(f"Fecha: {datos.get('fecha','')}")
    line(f"Cliente: {datos.get('cliente_nombre','')} {datos.get('cliente_apellido','')}")
    line(f"C.C / NIT: {datos.get('cliente_cc','N/A')}")
    line(f"Dirección: {datos.get('cliente_dir', datos.get('empresa_dir','Calle 18 #19c-133'))}")

    # Separador
    draw.line([(20, y+4), (width-20, y+4)], fill=(0,0,0), width=2)
    y += 14

    # Tabla
    line("CT   Descripción", x=20)
    line("Valor", x=500)
    y += 2
    draw.line([(20, y+4), (width-20, y+4)], fill=(0,0,0), width=1)
    y += 12
    for it in datos.get('items', []):
        draw.text((20, y), str(it.get('cantidad',1)), fill=(0,0,0), font=font)
        draw.text((70, y), str(it.get('descripcion','')), fill=(0,0,0), font=font)
        draw.text((500, y), f"{int(it.get('valor',0)):,}".replace(',', '.'), fill=(0,0,0), font=font)
        y += 24

    # Totales
    y += 6
    draw.text((380, y), "SUBTOTAL", fill=(0,0,0), font=font)
    draw.text((500, y), f"{int(datos.get('subtotal',0)):,}".replace(',', '.'), fill=(0,0,0), font=font)
    y += 22
    draw.text((360, y), "Total", fill=(0,0,0), font=font)
    draw.text((500, y), f"{int(datos.get('total',0)):,}".replace(',', '.'), fill=(0,0,0), font=font)

    # Forma de pago
    y += 20
    draw.line([(20, y+4), (width-20, y+4)], fill=(0,0,0), width=2)
    y += 14
    line(f"Forma de Pago: {datos.get('metodo','N/A')}")
    if datos.get('efectivo') is not None:
        line(f"Efectivo: {int(datos.get('efectivo',0)):,}".replace(',', '.'))
    if datos.get('cambio') is not None:
        line(f"Cambio: {int(datos.get('cambio',0)):,}".replace(',', '.'))

    # Pie
    y += 8
    draw.line([(20, y+4), (width-20, y+4)], fill=(0,0,0), width=1)
    y += 12
    line("Elaborado por: gimnasio komdes word", x=160)
    line(datos.get('komdez_url','ww.komdez.com'), x=230)

    os.makedirs(os.path.dirname(destino), exist_ok=True)
    img.save(destino, format='PNG')
    return destino

def obtener_conexion():
    return pymysql.connect(
        host='127.0.0.1',
        user='root',
        password='',
        database='ginnasio',
        cursorclass=pymysql.cursors.DictCursor
    )

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.after_request
def agregar_encabezados(response):
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

# Filtro global: exigir sesión para acceder a rutas protegidas
@app.before_request
def requerir_login_global():
    # Endpoints públicos que no requieren sesión
    allowlist = {"login", "register", "forgot", "reset_password", "static"}
    ep = request.endpoint
    # Permitir archivos estáticos o endpoints explícitos en la lista blanca
    if ep in allowlist or (request.path or "").startswith("/static/"):
        return
    # Si no hay usuario en sesión, redirigir a login
    if "usuario" not in session:
        return redirect(url_for("login"))

# Decorador para proteger rutas
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# -------------------
# Dashboard principal
# -------------------
@app.route('/')
@login_required
def index():
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            # Total de clientes
            cursor.execute("SELECT COUNT(*) AS total FROM clientes")
            total_miembros = cursor.fetchone()['total']

            # Nuevas inscripciones este mes
            cursor.execute("""
                SELECT COUNT(*) AS nuevos
                  FROM clientes
                 WHERE MONTH(fecha_registro)=MONTH(CURRENT_DATE())
                   AND YEAR(fecha_registro)=YEAR(CURRENT_DATE())
            """)
            nuevas_inscripciones = cursor.fetchone()['nuevos']

            # Miembros activos (conteo)
            cursor.execute("""
                SELECT COUNT(DISTINCT id_cliente) AS activos
                  FROM membresias
                 WHERE fecha_fin >= CURRENT_DATE()
            """)
            miembros_activos = cursor.fetchone()['activos']

            # Listado de clientes activos con detalles y foto
            cursor.execute("""
                SELECT
                    c.*, 
                    t.nombre    AS tipo_membresia,
                    m.fecha_fin AS proximo_pago
                FROM clientes c
                JOIN membresias m ON c.id_cliente = m.id_cliente
                LEFT JOIN tipos_membresia t ON m.id_tipo_membresia = t.id_tipo_membresia
                WHERE m.fecha_fin >= CURRENT_DATE()
                ORDER BY c.nombre ASC
            """)
            clientes_activos = cursor.fetchall()

            # Normalizar foto_url y estado
            for cliente in clientes_activos:
                cliente['estado_pago'] = 'activo'
                foto_nombre = cliente.get('foto')
                if foto_nombre:
                    if foto_nombre.startswith('uploads/'):
                        cliente['foto_url'] = url_for('static', filename=foto_nombre)
                    else:
                        cliente['foto_url'] = url_for('static', filename=f"uploads/{foto_nombre}")
                else:
                    cliente['foto_url'] = url_for('static', filename='img/default-user.png')

            # Pagos próximos a vencer
            cursor.execute("""
                SELECT
                    c.*,                   -- todos los datos del cliente
                    m.id_membresia,
                    m.fecha_fin,
                    t.nombre    AS tipo_membresia,
                    t.precio    AS costo
                FROM membresias m
                JOIN clientes c ON m.id_cliente = c.id_cliente
                JOIN tipos_membresia t ON m.id_tipo_membresia = t.id_tipo_membresia
                WHERE m.fecha_fin < CURRENT_DATE()
                ORDER BY m.fecha_fin DESC
            """)
            membresias_vencidas = cursor.fetchall()

            # Foto y campos derivados para recordatorio
            for m in membresias_vencidas:
                foto_nombre = m.get('foto')
                if foto_nombre:
                    if foto_nombre.startswith('uploads/'):
                        m['foto_url'] = url_for('static', filename=foto_nombre)
                    else:
                        m['foto_url'] = url_for('static', filename=f"uploads/{foto_nombre}")
                else:
                    m['foto_url'] = url_for('static', filename='img/default-user.png')

            # Ingresos del día
            cursor.execute("SELECT SUM(monto) AS total FROM pagos WHERE DATE(fecha_pago)=CURRENT_DATE()")
            ingresos = cursor.fetchone()
            ingresos_dia = ingresos['total'] or 0

        return render_template('dashboard.html',
            total_miembros=total_miembros,
            nuevas_inscripciones=nuevas_inscripciones,
            miembros_activos=miembros_activos,
            membresias_vencidas=membresias_vencidas,
            clientes_activos=clientes_activos,
            ingresos_dia=ingresos_dia
        )
    except Exception as e:
        return jsonify({"message": f"Error: {e}"}), 500
    finally:
        conn.close()

# -------- RUTAS PARA CLIENTES --------
@app.route('/clientes', methods=['GET'])
def obtener_clientes():
    conn = None
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT
                  c.*,
                  t.nombre     AS tipo_membresia,
                  m.fecha_fin  AS proximo_pago
                FROM clientes c
                LEFT JOIN membresias m ON c.id_cliente = m.id_cliente
                LEFT JOIN tipos_membresia t ON m.id_tipo_membresia = t.id_tipo_membresia
                ORDER BY c.fecha_registro DESC
            """)
            clientes = cursor.fetchall()

            # Procesar cada cliente
            for cliente in clientes:
                # Estado de pago
                if cliente.get('proximo_pago'):
                    cliente['estado_pago'] = "activo" if cliente['proximo_pago'] >= date.today() else "vencido"
                else:
                    cliente['estado_pago'] = "sin registro"

                # Progreso físico (placeholder)
                cliente['progreso_fisico'] = 0

                # Foto: soporte para nombre de archivo o ruta ya guardada
                foto_nombre = cliente.get('foto')
                if foto_nombre:
                    if foto_nombre.startswith('uploads/'):
                        cliente['foto_url'] = url_for('static', filename=foto_nombre)
                    else:
                        cliente['foto_url'] = url_for('static', filename=f'uploads/{foto_nombre}')
                else:
                    # asegura que static/default.jpg exista
                    cliente['foto_url'] = url_for('static', filename='default.jpg')

                # Medidas corporales: traer último registro si existe
                try:
                    cursor.execute(
                        "SELECT peso, altura, imc, cintura, pecho, brazo, pierna, observaciones FROM medidas_corporales WHERE id_cliente=%s ORDER BY id_medida DESC LIMIT 1",
                        (cliente['id_cliente'],)
                    )
                    cliente['medidas'] = cursor.fetchone() or {}
                except Exception:
                    try:
                        cursor.execute(
                            "SELECT peso, altura, imc, cintura, pecho, brazo, pierna, observaciones FROM medidas_corporales WHERE id_cliente=%s ORDER BY id DESC LIMIT 1",
                            (cliente['id_cliente'],)
                        )
                        cliente['medidas'] = cursor.fetchone() or {}
                    except Exception:
                        cliente['medidas'] = {}

        return render_template('clientes.html', clientes=clientes)

    except Exception as e:
        flash(f"Error al cargar clientes: {e}", "danger")
        return redirect(url_for('index'))
    finally:
        if conn:
            conn.close()

@app.route('/clientes/nuevo', methods=['GET', 'POST'])
def nuevo_cliente():
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        apellido = request.form.get('apellido')
        identificacion = request.form.get('identificacion')
        genero = request.form.get('genero')
        fecha_nacimiento = request.form.get('fecha_nacimiento')
        telefono = request.form.get('telefono')
        # Campos opcionales: email y dirección pueden faltar porque se retiraron del formulario
        email = request.form.get('email', '')
        direccion = request.form.get('direccion', '')
        enfermedades = request.form.get('enfermedades')
        alergias = request.form.get('alergias')
        fracturas = request.form.get('fracturas')
        observaciones = request.form.get('observaciones_medicas')

        # Medidas corporales (opcional)
        def to_decimal(val):
            try:
                if val is None or val == '':
                    return None
                return float(val)
            except Exception:
                return None

        peso = to_decimal(request.form.get('peso'))
        altura = to_decimal(request.form.get('altura'))
        imc = to_decimal(request.form.get('imc'))
        cintura = to_decimal(request.form.get('cintura'))
        pecho = to_decimal(request.form.get('pecho'))
        brazo = to_decimal(request.form.get('brazo'))
        pierna = to_decimal(request.form.get('pierna'))
        observaciones_medidas = request.form.get('observaciones_medidas')

        foto = request.files.get('foto')
        nombre_foto = None

        if foto and foto.filename != '' and allowed_file(foto.filename):
            filename = secure_filename(foto.filename)
            if identificacion:
                filename = f"{identificacion}_{filename}"
            else:
                filename = f"{uuid.uuid4().hex[:8]}_{filename}"
            save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            foto.save(save_path)
            nombre_foto = filename

        conn = obtener_conexion()
        try:
            with conn.cursor() as cursor:
                sql = """
                    INSERT INTO clientes (
                        nombre, apellido, identificacion, genero, fecha_nacimiento,
                        telefono, email, direccion, foto, enfermedades, alergias,
                        fracturas, observaciones_medicas
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, (
                    nombre, apellido, identificacion, genero, fecha_nacimiento,
                    (telefono or ''), (email or ''), (direccion or ''), nombre_foto, (enfermedades or ''),
                    (alergias or ''), (fracturas or ''), (observaciones or '')
                ))

                id_cliente = cursor.lastrowid

                # Insertar medidas corporales si hay datos
                if any(v is not None for v in [peso, altura, imc, cintura, pecho, brazo, pierna]) or (observaciones_medidas and observaciones_medidas.strip()):
                    sql_medidas = """
                        INSERT INTO medidas_corporales (
                            id_cliente, peso, altura, imc, cintura, pecho, brazo, pierna, observaciones
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """
                    cursor.execute(sql_medidas, (
                        id_cliente, peso, altura, imc, cintura, pecho, brazo, pierna, observaciones_medidas
                    ))
            conn.commit()
            flash("✅ Cliente registrado exitosamente", "success")
            return redirect(url_for('obtener_clientes'))   # <--- IMPORTANTE
        except Exception as e:
            flash(f"❌ Error al registrar cliente: {e}", "danger")
            return redirect(url_for('nuevo_cliente'))
        finally:
            conn.close()

    return render_template('nuevo_cliente.html')



@app.route('/clientes/editar/<int:id>', methods=['GET', 'POST'])
def editar_cliente(id):
    conn = None
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            if request.method == 'POST':
                nombre = request.form['nombre']
                apellido = request.form['apellido']
                email = request.form['email']
                telefono = request.form['telefono']
                direccion = request.form['direccion']
                cursor.execute(
                    "UPDATE clientes SET nombre=%s, apellido=%s, email=%s, telefono=%s, direccion=%s WHERE id_cliente=%s",
                    (nombre, apellido, email, telefono, direccion, id)
                )
                conn.commit()
                flash("Cliente actualizado con éxito", "success")
                return redirect(url_for('obtener_clientes'))
            else:
                cursor.execute("SELECT * FROM clientes WHERE id_cliente = %s", (id,))
                cliente = cursor.fetchone()
                return render_template('editar_cliente.html', cliente=cliente)
    except Exception as e:
        flash(f"Error al editar cliente: {e}", "danger")
        return redirect(url_for('obtener_clientes'))
    finally:
        if conn: conn.close()

@app.route('/clientes/eliminar/<int:id>', methods=['POST'])
def eliminar_cliente(id):
    conn = None
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM clientes WHERE id_cliente = %s", (id,))
            conn.commit()
            flash("Cliente eliminado con éxito", "success")
            return redirect(url_for('obtener_clientes'))
    except Exception as e:
        flash(f"Error al eliminar cliente: {e}", "danger")
        return redirect(url_for('obtener_clientes'))
    finally:
        if conn: conn.close()
# -------- finanza --------



# -------- RUTAS PARA ENTRENADORES --------
@app.route('/entrenadores')
def obtener_entrenadores():
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM entrenadores")
            entrenadores = cursor.fetchall()
        return render_template('entrenadores.html', entrenadores=entrenadores)
    except Exception as e:
        flash(f"Error: {e}", "danger")
        return redirect(url_for('index'))
    finally:
        conn.close()

@app.route('/entrenadores/nuevo', methods=['GET', 'POST'])
def nuevo_entrenador():
    if request.method == 'POST':
        try:
            conn = obtener_conexion()
            with conn.cursor() as cursor:
                nombre = request.form['nombre']
                apellido = request.form['apellido']
                especialidad = request.form['especialidad']
                email = request.form['email']
                telefono = request.form['telefono']
                cursor.execute(
                    "INSERT INTO entrenadores (nombre, apellido, especialidad, email, telefono) VALUES (%s,%s,%s,%s,%s)",
                    (nombre, apellido, especialidad, email, telefono)
                )
                conn.commit()
                flash("Entrenador agregado con éxito", "success")
                return redirect(url_for('obtener_entrenadores'))
        except Exception as e:
            flash(f"Error: {e}", "danger")
            return render_template('nuevo_entrenador.html')
        finally:
            conn.close()
    return render_template('nuevo_entrenador.html')

@app.route('/entrenadores/editar/<int:id>', methods=['GET','POST'])
def editar_entrenador(id):
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            if request.method == 'POST':
                nombre, apellido = request.form['nombre'], request.form['apellido']
                especialidad, email = request.form['especialidad'], request.form['email']
                telefono = request.form['telefono']
                cursor.execute(
                    "UPDATE entrenadores SET nombre=%s,apellido=%s,especialidad=%s,email=%s,telefono=%s WHERE id_entrenador=%s",
                    (nombre, apellido, especialidad, email, telefono, id)
                )
                conn.commit()
                flash("Entrenador actualizado con éxito", "success")
                return redirect(url_for('obtener_entrenadores'))
            cursor.execute("SELECT * FROM entrenadores WHERE id_entrenador=%s", (id,))
            entrenador = cursor.fetchone()
            return render_template('editar_entrenador.html', entrenador=entrenador)
    except Exception as e:
        flash(f"Error: {e}", "danger")
        return redirect(url_for('obtener_entrenadores'))
    finally:
        conn.close()

@app.route('/entrenadores/eliminar/<int:id>', methods=['POST'])
def eliminar_entrenador(id):
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM entrenadores WHERE id_entrenador=%s", (id,))
            conn.commit()
            flash("Entrenador eliminado con éxito", "success")
            return redirect(url_for('obtener_entrenadores'))
    except Exception as e:
        flash(f"Error: {e}", "danger")
        return redirect(url_for('obtener_entrenadores'))
    finally:
        conn.close()

@app.route('/entrenadores/<int:id_entrenador>/asignar', methods=['GET','POST'])
def asignar_clase_entrenador(id_entrenador):
    """Crear una sesión (clase) para un entrenador y asignarla a un cliente.
    Además, permite registrar una rutina semanal básica con ejercicios predeterminados editables.
    """
    conn = obtener_conexion()
    try:
        with conn.cursor() as cur:
            # Datos del entrenador
            cur.execute("SELECT * FROM entrenadores WHERE id_entrenador=%s", (id_entrenador,))
            entrenador = cur.fetchone()
            if not entrenador:
                flash("Entrenador no encontrado", "danger")
                return redirect(url_for('obtener_entrenadores'))

            if request.method == 'POST':
                # Crear clase individual
                nombre_clase = request.form.get('nombre_clase') or f"Sesión con {entrenador['nombre']}"
                id_cliente = request.form['id_cliente']
                fecha_hora = request.form['fecha_hora']
                duracion = request.form.get('duracion') or 60
                cur.execute(
                    "INSERT INTO clases (nombre_clase,id_entrenador,fecha_hora,duracion,max_participantes) VALUES (%s,%s,%s,%s,%s)",
                    (nombre_clase, id_entrenador, fecha_hora, duracion, 1)
                )
                id_clase = cur.lastrowid

                # Inscribir cliente a la clase
                cur.execute(
                    "INSERT INTO inscripciones (id_cliente,id_clase) VALUES (%s,%s)",
                    (id_cliente, id_clase)
                )

                # Registrar rutina semanal opcional (Lunes-Viernes)
                fecha_inicio = request.form.get('fecha_inicio')
                if fecha_inicio:
                    fi = datetime.strptime(fecha_inicio, "%Y-%m-%d").date()
                    ff = fi + timedelta(days=6)
                    titulo = request.form.get('titulo_rutina') or f"Plan semanal de {entrenador['nombre']}"
                    descripcion = request.form.get('descripcion_rutina') or "Rutina generada desde Entrenadores"
                    cur.execute(
                        """
                        INSERT INTO rutinas_personalizadas
                          (titulo, descripcion, id_cliente, id_entrenador, fecha_inicio, fecha_fin, duracion_dias)
                        VALUES (%s,%s,%s,%s,%s,%s,%s)
                        """,
                        (titulo, descripcion, id_cliente, id_entrenador, fi, ff, 7)
                    )
                    id_rutina = cur.lastrowid

                    dias = ["Lunes","Martes","Miercoles","Jueves","Viernes"]
                    for d in dias:
                        hora = request.form.get(f"hora_{d}") or None
                        ejercicios = request.form.get(f"ej_{d}") or None
                        if hora or ejercicios:
                            cur.execute(
                                "INSERT INTO rutina_horarios (id_rutina, dia_semana, hora_programada, ejercicios) VALUES (%s,%s,%s,%s)",
                                (id_rutina, d, hora, ejercicios)
                            )

                conn.commit()
                flash("Clase asignada y rutina registrada (si se indicó) correctamente", "success")
                return redirect(url_for('obtener_entrenadores'))

            # GET: datos para el formulario
            cur.execute("SELECT id_cliente, nombre, apellido FROM clientes ORDER BY nombre ASC")
            clientes = cur.fetchall()
            defaults = {
                'Lunes': 'Pecho 4x12 + Cardio 20m',
                'Martes': 'Espalda 4x12 + Core 3x15',
                'Miercoles': 'Piernas 4x12 + Estiramientos',
                'Jueves': 'Hombros 4x12 + Cardio 15m',
                'Viernes': 'Full body 3x12 + Abdominales 3x20'
            }
            return render_template('asignar_clase_entrenador.html', entrenador=entrenador, clientes=clientes, defaults=defaults)
    except Exception as e:
        flash(f"Error: {e}", "danger")
        return redirect(url_for('obtener_entrenadores'))
    finally:
        conn.close()
# -------- RUTAS PARA CLASES --------
@app.route('/clases')
def obtener_clases():
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT c.*, e.nombre AS nombre_entrenador, e.apellido AS apellido_entrenador
                FROM clases c
                LEFT JOIN entrenadores e ON c.id_entrenador=e.id_entrenador
                ORDER BY c.fecha_hora
            """)
            clases = cursor.fetchall()
            cursor.execute("SELECT id_entrenador,nombre,apellido FROM entrenadores")
            entrenadores = cursor.fetchall()
        return render_template('clases.html', clases=clases, entrenadores=entrenadores)
    except Exception as e:
        flash(f"Error: {e}", "danger")
        return redirect(url_for('index'))
    finally:
        conn.close()

@app.route('/clases/nueva', methods=['GET','POST'])
def nueva_clase():
    if request.method=='POST':
        try:
            conn = obtener_conexion()
            with conn.cursor() as cursor:
                data = (request.form['nombre_clase'], request.form['id_entrenador'],
                        request.form['fecha_hora'], request.form['duracion'],
                        request.form['max_participantes'])
                cursor.execute(
                    "INSERT INTO clases (nombre_clase,id_entrenador,fecha_hora,duracion,max_participantes) VALUES (%s,%s,%s,%s,%s)",
                    data
                )
                conn.commit()
                flash("Clase agregada con éxito","success")
                return redirect(url_for('obtener_clases'))
        except Exception as e:
            flash(f"Error: {e}","danger")
            return redirect(url_for('obtener_clases'))
        finally:
            conn.close()
    conn = obtener_conexion()
    with conn.cursor() as cursor:
        cursor.execute("SELECT id_entrenador,nombre,apellido FROM entrenadores")
        entrenadores = cursor.fetchall()
    conn.close()
    return render_template('nueva_clase.html', entrenadores=entrenadores)

@app.route('/clases/editar/<int:id>', methods=['GET','POST'])
def editar_clase(id):
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            if request.method=='POST':
                data = (request.form['nombre_clase'],request.form['id_entrenador'],
                        request.form['fecha_hora'],request.form['duracion'],
                        request.form['max_participantes'],id)
                cursor.execute(
                    "UPDATE clases SET nombre_clase=%s,id_entrenador=%s,fecha_hora=%s,duracion=%s,max_participantes=%s WHERE id_clase=%s",
                    data
                )
                conn.commit()
                flash("Clase actualizada con éxito","success")
                return redirect(url_for('obtener_clases'))
            cursor.execute("SELECT * FROM clases WHERE id_clase=%s",(id,))
            clase = cursor.fetchone()
            cursor.execute("SELECT id_entrenador,nombre,apellido FROM entrenadores")
            entrenadores = cursor.fetchall()
        return render_template('editar_clase.html',clase=clase,entrenadores=entrenadores)
    except Exception as e:
        flash(f"Error: {e}","danger")
        return redirect(url_for('obtener_clases'))
    finally:
        conn.close()

@app.route('/clases/eliminar/<int:id>', methods=['POST'])
def eliminar_clase(id):
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM clases WHERE id_clase=%s",(id,))
            conn.commit()
            flash("Clase eliminada con éxito","success")
            return redirect(url_for('obtener_clases'))
    except Exception as e:
        flash(f"Error: {e}","danger")
        return redirect(url_for('obtener_clases'))
    finally:
        conn.close()
        
# Ingresos y gastos en la misma vista



# -------- RUTAS PARA GASTOS --------
@app.route('/productos')
def obtener_productos():
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            # Productos
            cursor.execute("SELECT * FROM producto ORDER BY creado_en DESC")
            productos = cursor.fetchall()

            # Crear tabla de promociones si no existe
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS promociones (
                    id_promocion INT AUTO_INCREMENT PRIMARY KEY,
                    id_producto INT NOT NULL,
                    precio_promocional DECIMAL(10,2) NOT NULL,
                    frase VARCHAR(255),
                    incluir_foto TINYINT(1) DEFAULT 1,
                    activo TINYINT(1) DEFAULT 1,
                    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """
            )

            # Promociones activas
            cursor.execute(
                """
                SELECT p.*, pr.nombre, pr.precio AS precio_base, pr.foto
                  FROM promociones p
                  JOIN producto pr ON p.id_producto = pr.id_producto
                 WHERE p.activo = 1
                 ORDER BY p.creado_en DESC
                """
            )
            promociones = cursor.fetchall()

            # Clientes para envío masivo
            cursor.execute("SELECT id_cliente, nombre, apellido, telefono, email FROM clientes ORDER BY nombre ASC")
            clientes = cursor.fetchall()
        # Base pública para compartir enlaces (opcional, via variable de entorno)
        share_base = os.environ.get('SHARE_BASE_URL')

        return render_template('productos.html', productos=productos, promociones=promociones, clientes=clientes, share_base=share_base)
    finally:
        conn.close()


@app.route('/productos/nuevo', methods=['GET','POST'])
def nuevo_producto():
    if request.method == 'POST':
        nombre = request.form['nombre']
        descripcion = request.form['descripcion']
        precio = parse_cop(request.form['precio'])
        stock = request.form['stock']

        foto = request.files.get('foto')
        filename = None
        if foto and foto.filename != '':
            filename = secure_filename(foto.filename)
            foto.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        conn = obtener_conexion()
        try:
            with conn.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO producto(nombre, descripcion, precio, stock, foto)
                    VALUES (%s,%s,%s,%s,%s)
                """, (nombre, descripcion, precio, stock, filename))
            conn.commit()
            flash("Producto agregado con éxito", "success")
            return redirect(url_for('obtener_productos'))
        finally:
            conn.close()
    return render_template('nuevo_producto.html')


@app.route('/productos/editar/<int:id_producto>', methods=['GET','POST'])
def editar_producto(id_producto):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM producto WHERE id_producto=%s", (id_producto,))
            producto = cursor.fetchone()

        if request.method == 'POST':
            nombre = request.form['nombre']
            descripcion = request.form['descripcion']
            precio = parse_cop(request.form['precio'])
            stock = request.form['stock']

            foto = request.files.get('foto')
            filename = producto['foto']
            if foto and foto.filename != '':
                filename = secure_filename(foto.filename)
                foto.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

            with conn.cursor() as cursor:
                cursor.execute("""
                    UPDATE producto SET nombre=%s, descripcion=%s, precio=%s, stock=%s, foto=%s, actualizado_en=NOW()
                    WHERE id_producto=%s
                """, (nombre, descripcion, precio, stock, filename, id_producto))
            conn.commit()
            flash("Producto actualizado con éxito", "success")
            return redirect(url_for('obtener_productos'))

        return render_template('editar_producto.html', producto=producto)
    finally:
        conn.close()


# -------- Promocionar producto --------
@app.route('/productos/promocionar/<int:id_producto>', methods=['POST'])
def promocionar_producto(id_producto):
    # Valores del formulario
    frase = request.form.get('frase', '').strip()
    incluir_foto = 1 if request.form.get('incluir_foto') == 'on' else 0
    try:
        precio_promocional = parse_cop(request.form.get('precio_promocional', '0'))
    except Exception:
        precio_promocional = 0

    if precio_promocional <= 0:
        flash('El precio promocional debe ser mayor a cero', 'danger')
        return redirect(url_for('obtener_productos'))

    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            # Asegurar existencia de tabla
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS promociones (
                    id_promocion INT AUTO_INCREMENT PRIMARY KEY,
                    id_producto INT NOT NULL,
                    precio_promocional DECIMAL(10,2) NOT NULL,
                    frase VARCHAR(255),
                    incluir_foto TINYINT(1) DEFAULT 1,
                    activo TINYINT(1) DEFAULT 1,
                    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
                """
            )

            cursor.execute(
                """
                INSERT INTO promociones(id_producto, precio_promocional, frase, incluir_foto, activo)
                VALUES (%s, %s, %s, %s, 1)
                """,
                (id_producto, precio_promocional, frase, incluir_foto)
            )
        conn.commit()
        flash('Promoción creada para el producto', 'success')
    except Exception as e:
        flash(f'Error al crear la promoción: {e}', 'danger')
    finally:
        conn.close()
    return redirect(url_for('obtener_productos'))


# -------- Desactivar promoción --------
@app.route('/promociones/desactivar/<int:id_promocion>', methods=['POST'])
def desactivar_promocion(id_promocion):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            cursor.execute("UPDATE promociones SET activo=0 WHERE id_promocion=%s", (id_promocion,))
        conn.commit()
        return jsonify({"status": "ok"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
    finally:
        conn.close()


@app.route('/productos/eliminar/<int:id_producto>', methods=['POST'])
def eliminar_producto(id_producto):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM producto WHERE id_producto=%s", (id_producto,))
        conn.commit()
        flash("Producto eliminado con éxito", "success")
    finally:
        conn.close()
    return redirect(url_for('obtener_productos'))

# -------- Página compartible de promoción (Open Graph) --------
@app.route('/promo/<int:id_promocion>')
def promo_share(id_promocion):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT p.*, pr.nombre, pr.descripcion, pr.foto
                  FROM promociones p
                  JOIN producto pr ON p.id_producto = pr.id_producto
                 WHERE p.id_promocion = %s
                """,
                (id_promocion,)
            )
            promo = cur.fetchone()

        if not promo:
            return render_template('promo_share.html', promo=None, image_url=None, title='Promoción no encontrada')

        # Construye URL absoluta de imagen usando dominio público si está configurado
        share_base = os.environ.get('SHARE_BASE_URL')
        base = share_base or request.url_root
        image_url = None
        if promo.get('incluir_foto') and promo.get('foto'):
            image_url = urljoin(base, url_for('static', filename=f"uploads/{promo['foto']}"))

        title = f"Promoción: {promo['nombre']}"
        return render_template('promo_share.html', promo=promo, image_url=image_url, title=title)
    except Exception as e:
        flash(f"Error al generar página de promoción: {e}", "danger")
        return redirect(url_for('obtener_productos'))
    finally:
        conn.close()


# =================== VENTAS (Producto -> Finanzas) ===================
@app.route('/ventas/nueva/<int:id_producto>', methods=['GET','POST'])
def nueva_venta(id_producto):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM producto WHERE id_producto=%s", (id_producto,))
            producto = cursor.fetchone()
            cursor.execute("SELECT id_cliente, nombre, apellido, telefono, email FROM clientes ORDER BY nombre ASC")
            clientes = cursor.fetchall()

        if request.method == 'POST':
            cantidad = int(request.form['cantidad'])
            total = float(producto['precio']) * cantidad
            id_cliente = request.form.get('id_cliente')
            metodo_pago = request.form.get('metodo_pago') or 'Efectivo'
            efectivo_recibido = request.form.get('efectivo_recibido')
            try:
                efectivo_val = float(efectivo_recibido) if efectivo_recibido else None
            except:
                efectivo_val = None
            cambio = (efectivo_val - total) if (efectivo_val is not None) else None

            with conn.cursor() as cursor:
                cursor.execute("INSERT INTO ventas(id_producto, cantidad, total) VALUES (%s,%s,%s)",
                               (id_producto, cantidad, total))
                id_venta = cursor.lastrowid
                cursor.execute("UPDATE producto SET stock = stock - %s WHERE id_producto=%s",
                               (cantidad, id_producto))

                # Registrar ingreso en finanzas
                cursor.execute("""
                    INSERT INTO finanzas(descripcion, monto, tipo, origen, fecha)
                    VALUES (%s,%s,'ingreso','venta producto',NOW())
                """, (f"Venta de {producto['nombre']} (x{cantidad})", total))

            conn.commit()
            flash("Venta registrada y añadida a finanzas", "success")
            return redirect(url_for('factura_venta', id_venta=id_venta, id_cliente=id_cliente, metodo_pago=metodo_pago, efectivo=(efectivo_val if efectivo_val is not None else ''), cambio=(cambio if cambio is not None else '')))

        return render_template('nueva_venta.html', producto=producto, clientes=clientes)
    finally:
        conn.close()


# -------- FACTURA: VENTA --------
@app.route('/factura/venta/<int:id_venta>')
def factura_venta(id_venta):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT v.id_venta, v.cantidad, v.total, p.nombre AS producto, p.precio
                  FROM ventas v
                  JOIN producto p ON v.id_producto = p.id_producto
                 WHERE v.id_venta=%s
                """,
                (id_venta,)
            )
            v = cursor.fetchone()
            if not v:
                flash("Venta no encontrada", "danger")
                return redirect(url_for('obtener_productos'))

            id_cliente = request.args.get('id_cliente')
            cliente = {'nombre':'Cliente', 'apellido':'', 'cc':None, 'direccion':None, 'telefono':None, 'email':None}
            if id_cliente:
                cursor.execute("SELECT nombre,apellido,telefono,email,identificacion,direccion FROM clientes WHERE id_cliente=%s", (id_cliente,))
                c = cursor.fetchone()
                if c:
                    cliente.update({
                        'nombre': c.get('nombre'),
                        'apellido': c.get('apellido'),
                        'telefono': c.get('telefono'),
                        'email': c.get('email'),
                        'cc': c.get('identificacion'),
                        'direccion': c.get('direccion')
                    })

        items = [{
            'cantidad': v['cantidad'],
            'descripcion': v['producto'],
            'valor': float(v['total'])
        }]
        subtotal = float(v['total'])
        total = subtotal

        metodo = request.args.get('metodo_pago') or 'Efectivo'
        efectivo = request.args.get('efectivo')
        cambio = request.args.get('cambio')
        try:
            efectivo_val = float(efectivo) if efectivo else None
        except:
            efectivo_val = None
        try:
            cambio_val = float(cambio) if cambio else None
        except:
            cambio_val = None

        factura_url = url_for('factura_venta', id_venta=id_venta, _external=True)

        # Crear imagen directa y compartir URL absoluta del archivo estático
        datos_img = {
            'nit': generar_nit(),
            'dian': generar_resolucion_dian(),
            'empresa_dir': (os.environ.get('EMPRESA_DIR') or 'Calle 18 #19c-133'),
            'fecha': datetime.now().strftime('%Y-%m-%d %H:%M'),
            'factura_numero': f"POS - {id_venta}",
            'cliente_nombre': cliente.get('nombre'),
            'cliente_apellido': cliente.get('apellido'),
            'cliente_cc': cliente.get('cc') or 'N/A',
            'cliente_dir': cliente.get('direccion') or (os.environ.get('EMPRESA_DIR') or 'Calle 18 #19c-133'),
            'items': items,
            'subtotal': subtotal,
            'total': total,
            'metodo': metodo,
            'efectivo': efectivo_val,
            'cambio': cambio_val,
            'komdez_url': 'ww.komdez.com'
        }
        filename = f"factura_venta_{id_venta}.png"
        path = os.path.join(FACTURAS_FOLDER, filename)
        crear_imagen_factura(datos_img, path)
        static_img_rel = f"uploads/facturas/{filename}"
        factura_img_abs = build_public_url(url_for('static', filename=static_img_rel))
        mensaje = f"Factura {id_venta} - {v['producto']} x{v['cantidad']}\nTotal: COP ${int(total):,}\nCliente: {cliente.get('nombre','')} {cliente.get('apellido','')}\nVer: {factura_url}"
        tel = (cliente.get('telefono') or '').replace(' ', '')
        whatsapp_url = f"https://wa.me/{tel}?text={urllib.parse.quote(mensaje)}" if tel else "#"
        whatsapp_img_url = f"https://wa.me/{tel}?text={urllib.parse.quote(factura_img_abs)}" if tel else "#"
        email = cliente.get('email') or ''
        subject = f"Factura {id_venta}"
        email_body = f"Imagen de la factura: {factura_img_abs}\nFactura detallada: {factura_url}"
        email_url = f"mailto:{email}?subject={urllib.parse.quote(subject)}&body={urllib.parse.quote(email_body)}"

        return render_template('factura.html',
            factura_numero=f"POS - {id_venta}",
            fecha=datetime.now().strftime('%Y-%m-%d %H:%M'),
            cliente=cliente,
            items=items,
            subtotal=subtotal,
            total=total,
            metodo_pago=metodo,
            efectivo_recibido=efectivo_val,
            cambio=cambio_val,
            whatsapp_url=whatsapp_url,
            whatsapp_img_url=whatsapp_img_url,
            factura_img_url=factura_img_abs,
            email_url=email_url,
            empresa_nit=os.environ.get('EMPRESA_NIT'),
            empresa_tel=os.environ.get('EMPRESA_TEL'),
            empresa_dir=(os.environ.get('EMPRESA_DIR') or 'Calle 18 #19c-133'),
            nit_rnd=generar_nit(),
            dian_res=generar_resolucion_dian(),
            komdez_url='ww.komdez.com'
        )
    finally:
        conn.close()

# -------- FACTURA: PAGO/MEMBRESÍA --------
@app.route('/factura/pago/<int:id_pago>')
def factura_pago(id_pago):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT p.id_pago, p.monto, p.metodo_pago,
                       c.nombre, c.apellido, c.telefono, c.email, c.identificacion, c.direccion,
                       t.nombre AS tipo_membresia
                  FROM pagos p
                  JOIN clientes c ON p.id_cliente=c.id_cliente
                  LEFT JOIN membresias m ON p.id_membresia=m.id_membresia
                  LEFT JOIN tipos_membresia t ON m.id_tipo_membresia=t.id_tipo_membresia
                 WHERE p.id_pago=%s
                """,
                (id_pago,)
            )
            p = cursor.fetchone()
            if not p:
                flash("Pago no encontrado", "danger")
                return redirect(url_for('obtener_pagos'))

        items = [{
            'cantidad': 1,
            'descripcion': f"Pago membresía: {p.get('tipo_membresia') or 'General'}",
            'valor': float(p['monto'])
        }]
        total = float(p['monto'])

        factura_url = url_for('factura_pago', id_pago=id_pago, _external=True)

        # Crear imagen directa y compartir URL absoluta del archivo estático
        datos_img = {
            'nit': generar_nit(),
            'dian': generar_resolucion_dian(),
            'empresa_dir': (os.environ.get('EMPRESA_DIR') or 'Calle 18 #19c-133'),
            'fecha': datetime.now().strftime('%Y-%m-%d %H:%M'),
            'factura_numero': f"POS - {id_pago}",
            'cliente_nombre': p['nombre'],
            'cliente_apellido': p['apellido'],
            'cliente_cc': p.get('identificacion') or 'N/A',
            'cliente_dir': p.get('direccion') or (os.environ.get('EMPRESA_DIR') or 'Calle 18 #19c-133'),
            'items': items,
            'subtotal': total,
            'total': total,
            'metodo': p.get('metodo_pago'),
            'efectivo': None,
            'cambio': None,
            'komdez_url': 'ww.komdez.com'
        }
        filename = f"factura_pago_{id_pago}.png"
        path = os.path.join(FACTURAS_FOLDER, filename)
        crear_imagen_factura(datos_img, path)
        static_img_rel = f"uploads/facturas/{filename}"
        factura_img_abs = build_public_url(url_for('static', filename=static_img_rel))
        mensaje = f"Factura pago #{id_pago}\nConcepto: {items[0]['descripcion']}\nTotal: COP ${int(total):,}\nCliente: {p['nombre']} {p['apellido']}\nVer: {factura_url}"
        tel = (p.get('telefono') or '').replace(' ', '')
        whatsapp_url = f"https://wa.me/{tel}?text={urllib.parse.quote(mensaje)}" if tel else "#"
        whatsapp_img_url = f"https://wa.me/{tel}?text={urllib.parse.quote(factura_img_abs)}" if tel else "#"
        email = p.get('email') or ''
        subject = f"Factura pago #{id_pago}"
        email_body = f"Imagen de la factura: {factura_img_abs}\nFactura detallada: {factura_url}"
        email_url = f"mailto:{email}?subject={urllib.parse.quote(subject)}&body={urllib.parse.quote(email_body)}"

        cliente = {
            'nombre': p['nombre'],
            'apellido': p['apellido'],
            'telefono': p.get('telefono'),
            'email': p.get('email'),
            'cc': p.get('identificacion'),
            'direccion': p.get('direccion')
        }

        return render_template('factura.html',
            factura_numero=f"POS - {id_pago}",
            fecha=datetime.now().strftime('%Y-%m-%d %H:%M'),
            cliente=cliente,
            items=items,
            subtotal=total,
            total=total,
            metodo_pago=p.get('metodo_pago'),
            efectivo_recibido=None,
            cambio=None,
            whatsapp_url=whatsapp_url,
            whatsapp_img_url=whatsapp_img_url,
            factura_img_url=factura_img_abs,
            email_url=email_url,
            empresa_nit=os.environ.get('EMPRESA_NIT'),
            empresa_tel=os.environ.get('EMPRESA_TEL'),
            empresa_dir=(os.environ.get('EMPRESA_DIR') or 'Calle 18 #19c-133'),
            nit_rnd=generar_nit(),
            dian_res=generar_resolucion_dian(),
            komdez_url='ww.komdez.com'
        )
    finally:
        conn.close()


# -------- IMAGEN DE FACTURA: VENTA --------
@app.route('/factura/venta/<int:id_venta>/imagen')
def factura_venta_imagen(id_venta):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT v.id_venta, v.cantidad, v.total, p.nombre AS producto
                  FROM ventas v
                  JOIN producto p ON v.id_producto = p.id_producto
                 WHERE v.id_venta=%s
                """,
                (id_venta,)
            )
            v = cursor.fetchone()
            if not v:
                flash("Venta no encontrada", "danger")
                return redirect(url_for('obtener_productos'))

        # Datos básicos
        items = [{
            'cantidad': v['cantidad'],
            'descripcion': v['producto'],
            'valor': float(v['total'])
        }]
        datos = {
            'nit': generar_nit(),
            'dian': generar_resolucion_dian(),
            'empresa_dir': (os.environ.get('EMPRESA_DIR') or 'Calle 18 #19c-133'),
            'fecha': datetime.now().strftime('%Y-%m-%d %H:%M'),
            'factura_numero': f"POS - {id_venta}",
            'cliente_nombre': request.args.get('nombre') or 'Cliente',
            'cliente_apellido': request.args.get('apellido') or '',
            'cliente_cc': request.args.get('cc') or 'N/A',
            'cliente_dir': request.args.get('dir') or (os.environ.get('EMPRESA_DIR') or 'Calle 18 #19c-133'),
            'items': items,
            'subtotal': float(v['total']),
            'total': float(v['total']),
            'metodo': request.args.get('metodo') or 'Efectivo',
            'efectivo': (float(request.args.get('efectivo')) if request.args.get('efectivo') else None),
            'cambio': (float(request.args.get('cambio')) if request.args.get('cambio') else None),
            'komdez_url': 'ww.komdez.com'
        }
        filename = f"factura_venta_{id_venta}.png"
        path = os.path.join(FACTURAS_FOLDER, filename)
        crear_imagen_factura(datos, path)
        return redirect(url_for('static', filename=f"uploads/facturas/{filename}"))
    finally:
        conn.close()


# -------- IMAGEN DE FACTURA: PAGO --------
@app.route('/factura/pago/<int:id_pago>/imagen')
def factura_pago_imagen(id_pago):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT p.id_pago, p.monto, p.metodo_pago,
                       c.nombre, c.apellido, c.identificacion, c.direccion
                  FROM pagos p
                  JOIN clientes c ON p.id_cliente=c.id_cliente
                 WHERE p.id_pago=%s
                """,
                (id_pago,)
            )
            r = cursor.fetchone()
            if not r:
                flash("Pago no encontrado", "danger")
                return redirect(url_for('obtener_pagos'))

        items = [{
            'cantidad': 1,
            'descripcion': 'Pago membresía',
            'valor': float(r['monto'])
        }]
        datos = {
            'nit': generar_nit(),
            'dian': generar_resolucion_dian(),
            'empresa_dir': (os.environ.get('EMPRESA_DIR') or 'Calle 18 #19c-133'),
            'fecha': datetime.now().strftime('%Y-%m-%d %H:%M'),
            'factura_numero': f"POS - {id_pago}",
            'cliente_nombre': r['nombre'],
            'cliente_apellido': r['apellido'],
            'cliente_cc': r.get('identificacion') or 'N/A',
            'cliente_dir': r.get('direccion') or (os.environ.get('EMPRESA_DIR') or 'Calle 18 #19c-133'),
            'items': items,
            'subtotal': float(r['monto']),
            'total': float(r['monto']),
            'metodo': r.get('metodo_pago') or 'Efectivo',
            'efectivo': None,
            'cambio': None,
            'komdez_url': 'ww.komdez.com'
        }
        filename = f"factura_pago_{id_pago}.png"
        path = os.path.join(FACTURAS_FOLDER, filename)
        crear_imagen_factura(datos, path)
        return redirect(url_for('static', filename=f"uploads/facturas/{filename}"))
    finally:
        conn.close()


# =================== PAGOS MEMBRESÍAS (Ingreso -> Finanzas) ===================

# =================== FINANZAS (Ingresos + Gastos) ===================
@app.route('/finanzas')
def finanzas():
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM finanzas ORDER BY fecha DESC")
            movimientos = cursor.fetchall()

            cursor.execute("SELECT SUM(monto) as total FROM finanzas WHERE tipo='ingreso'")
            total_ingresos = cursor.fetchone()['total']

            cursor.execute("SELECT SUM(monto) as total FROM finanzas WHERE tipo='gasto'")
            total_gastos = cursor.fetchone()['total']

        return render_template('finanzas.html', movimientos=movimientos,
                               total_ingresos=total_ingresos, total_gastos=total_gastos)
    finally:
        conn.close()

# =================== BACKUP/DESCARGA ===================
@app.route('/backup/descargar')
def descargar_backup():
    try:
        import shutil, os
        from datetime import datetime
        # Carpeta del proyecto Python (plantillas, estáticos, app)
        base_dir = os.path.abspath(os.path.dirname(__file__))
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        zip_base = os.path.join(base_dir, f"gimnasio_app_backup_{timestamp}")
        # Crear ZIP del proyecto (carpeta actual)
        shutil.make_archive(zip_base, 'zip', base_dir)
        zip_path = f"{zip_base}.zip"
        # Enviar como archivo descargable
        return send_file(zip_path, as_attachment=True, download_name=os.path.basename(zip_path), mimetype='application/zip')
    except Exception as e:
        flash(f"Error al generar backup: {e}", "danger")
        return redirect(url_for('index'))


# =================== GASTOS MANUALES ===================
@app.route('/finanzas/nuevo_gasto', methods=['GET','POST'])
def nuevo_gasto():
    if request.method == 'POST':
        descripcion = request.form['descripcion']
        monto = parse_cop(request.form['monto'])

        conn = obtener_conexion()
        try:
            with conn.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO finanzas(descripcion, monto, tipo, origen, fecha)
                    VALUES (%s,%s,'gasto','manual',NOW())
                """, (descripcion, monto))
            conn.commit()
            flash("Gasto agregado correctamente", "success")
            return redirect(url_for('finanzas'))
        finally:
            conn.close()
    return render_template('nuevo_gasto.html')


@app.route('/finanzas/editar/<int:id>', methods=['GET','POST'])
def editar_gasto(id):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM finanzas WHERE id_finanza=%s", (id,))
            gasto = cursor.fetchone()

        if not gasto or gasto['tipo'] != 'gasto':
            flash("No se puede editar este registro", "danger")
            return redirect(url_for('finanzas'))

        if request.method == 'POST':
            descripcion = request.form['descripcion']
            monto = parse_cop(request.form['monto'])

            with conn.cursor() as cursor:
                cursor.execute("""
                    UPDATE finanzas SET descripcion=%s, monto=%s, fecha=NOW() WHERE id_finanza=%s
                """, (descripcion, monto, id))
            conn.commit()
            flash("Gasto actualizado", "success")
            return redirect(url_for('finanzas'))

        return render_template('editar_gasto.html', gasto=gasto)
    finally:
        conn.close()


@app.route('/finanzas/eliminar/<int:id>', methods=['POST'])
def eliminar_gasto(id):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM finanzas WHERE id_finanza=%s AND tipo='gasto'", (id,))
        conn.commit()
        flash("Gasto eliminado", "success")
    finally:
        conn.close()
    return redirect(url_for('finanzas'))

# -------- RUTAS PARA INSCRIPCIONES --------
@app.route('/inscripciones')
def obtener_inscripciones():
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT i.*, c.nombre AS nombre_cliente, c.apellido AS apellido_cliente, cl.nombre_clase
                FROM inscripciones i
                JOIN clientes c ON i.id_cliente=c.id_cliente
                JOIN clases cl ON i.id_clase=cl.id_clase
                ORDER BY i.fecha_inscripcion DESC
            """)
            inscripciones = cursor.fetchall()
            cursor.execute("SELECT id_cliente,nombre,apellido FROM clientes")
            clientes = cursor.fetchall()
            cursor.execute("SELECT id_clase,nombre_clase,fecha_hora FROM clases WHERE fecha_hora>NOW()")
            clases = cursor.fetchall()
        return render_template('inscripciones.html', inscripciones=inscripciones, clientes=clientes, clases=clases)
    except Exception as e:
        flash(f"Error: {e}","danger")
        return redirect(url_for('index'))
    finally:
        conn.close()

@app.route('/inscripciones/nueva', methods=['GET','POST'])
def nueva_inscripcion():
    if request.method=='POST':
        try:
            conn = obtener_conexion()
            with conn.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO inscripciones (id_cliente,id_clase) VALUES (%s,%s)",
                    (request.form['id_cliente'],request.form['id_clase'])
                )
                conn.commit()
                flash("Inscripción realizada con éxito","success")
                return redirect(url_for('obtener_inscripciones'))
        except Exception as e:
            flash(f"Error: {e}","danger")
            return redirect(url_for('obtener_inscripciones'))
        finally:
            conn.close()
    conn = obtener_conexion()
    with conn.cursor() as cursor:
        cursor.execute("SELECT id_cliente,nombre,apellido FROM clientes")
        clientes = cursor.fetchall()
        cursor.execute("SELECT id_clase,nombre_clase,fecha_hora FROM clases WHERE fecha_hora>NOW()")
        clases = cursor.fetchall()
    conn.close()
    return render_template('nueva_inscripcion.html', clientes=clientes, clases=clases)

@app.route('/inscripciones/eliminar/<int:id>', methods=['POST'])
def eliminar_inscripcion(id):
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM inscripciones WHERE id_inscripcion=%s",(id,))
            conn.commit()
            flash("Inscripción eliminada con éxito","success")
            return redirect(url_for('obtener_inscripciones'))
    except Exception as e:
        flash(f"Error: {e}","danger")
        return redirect(url_for('obtener_inscripciones'))
    finally:
        conn.close()

# -------- RUTAS PARA MEMBRESIAS --------
# ------------------ LISTAR MEMBRESÍAS ------------------
@app.route('/membresias')
def obtener_membresias():
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT 
                    m.id_membresia,
                    c.nombre AS nombre_cliente,
                    c.apellido AS apellido_cliente,
                    t.nombre AS tipo_membresia,
                    t.duracion_dias,
                    m.fecha_inicio,
                    m.fecha_fin
                FROM membresias m
                JOIN clientes c ON m.id_cliente = c.id_cliente
                LEFT JOIN tipos_membresia t ON m.id_tipo_membresia = t.id_tipo_membresia
                ORDER BY m.fecha_fin DESC
            """)
            membresias = cursor.fetchall()

        # 🔹 Si no hay tipo, significa que fue personalizada → calcular días y mostrarlo
        for m in membresias:
            if not m['tipo_membresia']:
                dias = (m['fecha_fin'] - m['fecha_inicio']).days
                m['tipo_membresia'] = f"Pase Diario ({dias} días)"

        # 🔹 Agregar fecha actual al contexto
        hoy = date.today()
        return render_template('membresias.html', membresias=membresias, hoy=hoy)
    except Exception as e:
        flash(f"Error: {e}", "danger")
        return redirect(url_for('index'))
    finally:
        if conn: conn.close()



# ------------------ NUEVA MEMBRESÍA ------------------



@app.route('/membresias/nueva', methods=['GET','POST'])
def nueva_membresia():
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            if request.method == 'POST':
                id_cliente = request.form['id_cliente']
                id_tipo = request.form.get('id_tipo_membresia')
                dias_personalizados = request.form.get('dias_personalizados')
                fecha_inicio = request.form['fecha_inicio']
                monto = parse_cop(request.form['monto'])
                metodo_pago = request.form['metodo_pago']
                numero_referencia = request.form.get('numero_referencia') or None

                # Calcular fecha de fin
                fecha_inicio_dt = datetime.strptime(fecha_inicio, "%Y-%m-%d")
                fecha_fin = None
                dias_tipo = None
                nombre_tipo = None

                if id_tipo == "personalizado" and dias_personalizados:
                    fecha_fin_dt = fecha_inicio_dt + timedelta(days=int(dias_personalizados))
                    fecha_fin = fecha_fin_dt.strftime("%Y-%m-%d")
                    id_tipo = None  # No se asocia a un tipo predefinido
                    dias_tipo = int(dias_personalizados)
                    nombre_tipo = "Personalizado"
                elif id_tipo:  
                    cursor.execute("SELECT nombre, duracion_dias FROM tipos_membresia WHERE id_tipo_membresia=%s", (id_tipo,))
                    tipo = cursor.fetchone()
                    if tipo:
                        dias = int(tipo['duracion_dias'])
                        fecha_fin_dt = fecha_inicio_dt + timedelta(days=dias)
                        fecha_fin = fecha_fin_dt.strftime("%Y-%m-%d")
                        dias_tipo = dias
                        nombre_tipo = tipo['nombre']

                # 1) Insertar membresía
                cursor.execute("""
                    INSERT INTO membresias (id_cliente, id_tipo_membresia, fecha_inicio, fecha_fin)
                    VALUES (%s, %s, %s, %s)
                """, (id_cliente, id_tipo, fecha_inicio, fecha_fin))
                conn.commit()

                id_membresia = cursor.lastrowid

                # 2) Insertar pago asociado
                cursor.execute("""
                    INSERT INTO pagos (id_cliente, id_membresia, monto, metodo_pago, numero_referencia)
                    VALUES (%s, %s, %s, %s, %s)
                """, (id_cliente, id_membresia, monto, metodo_pago, numero_referencia))
                conn.commit()

                # 3) Registrar ingreso en finanzas con detalle de frecuencia
                cursor.execute("SELECT nombre, apellido FROM clientes WHERE id_cliente=%s", (id_cliente,))
                cli = cursor.fetchone() or {'nombre':'Cliente','apellido':''}

                def etiqueta(d):
                    try:
                        d = int(d) if d is not None else None
                    except Exception:
                        d = None
                    if d is None: return 'personalizada'
                    if d <= 1: return 'por día'
                    if d == 15: return 'quincenal'
                    if 28 <= d <= 31: return 'mensual'
                    return f"{d} días"

                freq = etiqueta(dias_tipo)
                descripcion = f"Membresía {nombre_tipo or 'N/A'} ({freq}) - {cli['nombre']} {cli['apellido']}"
                origen = f"membresía {freq}"
                cursor.execute("""
                    INSERT INTO finanzas(descripcion, monto, tipo, origen, fecha)
                    VALUES (%s,%s,'ingreso',%s,NOW())
                """, (descripcion, monto, origen))
                conn.commit()

                flash("Membresía y pago registrados con éxito ✅", "success")
                return redirect(url_for('obtener_membresias'))

            # 🔹 Obtener clientes
            cursor.execute("SELECT id_cliente, nombre, apellido FROM clientes")
            clientes = cursor.fetchall()

            # 🔹 Obtener tipos de membresía
            cursor.execute("SELECT id_tipo_membresia, nombre, duracion_dias FROM tipos_membresia")
            tipos = cursor.fetchall()

        return render_template('nueva_membresia.html', clientes=clientes, tipos=tipos)
    except Exception as e:
        flash(f"Error: {e}", "danger")
        return redirect(url_for('obtener_membresias'))
    finally:
        conn.close()



# ------------------ EDITAR MEMBRESÍA ------------------
@app.route('/membresias/editar/<int:id>', methods=['GET', 'POST'])
def editar_membresia(id):
    conn = obtener_conexion()
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM membresias WHERE id_membresia=%s", (id,))
        membresia = cursor.fetchone()
        cursor.execute("SELECT id_cliente,nombre,apellido FROM clientes")
        clientes = cursor.fetchall()
        cursor.execute("SELECT * FROM tipos_membresia")
        tipos = cursor.fetchall()

    if request.method == 'POST':
        id_cliente = request.form['id_cliente']
        id_tipo = request.form['id_tipo_membresia']
        fecha_inicio = request.form['fecha_inicio']
        fecha_fin = request.form['fecha_fin']

        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("""
                UPDATE membresias
                SET id_cliente=%s, id_tipo_membresia=%s, fecha_inicio=%s, fecha_fin=%s
                WHERE id_membresia=%s
            """, (id_cliente, id_tipo, fecha_inicio, fecha_fin, id))
            conn.commit()
        flash("Membresía actualizada con éxito", "success")
        return redirect(url_for('obtener_membresias'))

    return render_template('editar_membresia.html', membresia=membresia, clientes=clientes, tipos=tipos)


# ------------------ ELIMINAR MEMBRESÍA ------------------
@app.route('/membresias/eliminar/<int:id>', methods=['POST'])
def eliminar_membresia(id):
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM membresias WHERE id_membresia=%s", (id,))
            conn.commit()
        flash("Membresía eliminada con éxito", "success")
        return redirect(url_for('obtener_membresias'))
    except Exception as e:
        flash(f"Error: {e}", "danger")
        return redirect(url_for('obtener_membresias'))
    finally:
        if conn: conn.close()

# -------- RUTAS PARA PAGOS --------
# ------------------ LISTAR PAGOS ------------------
@app.route('/pagos')
def obtener_pagos():
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT
                  p.*, 
                  c.nombre     AS nombre_cliente,
                  c.apellido   AS apellido_cliente,
                  t.nombre     AS tipo_membresia
                FROM pagos p
                JOIN clientes c ON p.id_cliente = c.id_cliente
                LEFT JOIN membresias m ON p.id_membresia = m.id_membresia
                LEFT JOIN tipos_membresia t ON m.id_tipo_membresia = t.id_tipo_membresia
                ORDER BY p.fecha_pago DESC
            """)
            pagos = cursor.fetchall()

            cursor.execute("SELECT id_cliente,nombre,apellido FROM clientes")
            clientes = cursor.fetchall()

            cursor.execute("""
                SELECT
                  m.id_membresia,
                  t.nombre AS tipo_membresia,
                  m.fecha_inicio,
                  m.fecha_fin
                FROM membresias m
                JOIN tipos_membresia t ON m.id_tipo_membresia=t.id_tipo_membresia
                WHERE m.fecha_fin>=CURRENT_DATE()
            """)
            membresias = cursor.fetchall()

        return render_template('pagos.html', pagos=pagos, clientes=clientes, membresias=membresias)
    except Exception as e:
        flash(f"Error: {e}", "danger")
        return redirect(url_for('index'))
    finally:
        if conn: conn.close()


# ------------------ NUEVO PAGO ------------------
@app.route('/pagos/nuevo', methods=['GET','POST'])
def nuevo_pago():
    if request.method=='POST':
        try:
            conn = obtener_conexion()
            with conn.cursor() as cursor:
                id_cliente = request.form['id_cliente']
                id_memb = request.form.get('id_membresia') or None
                monto = parse_cop(request.form['monto'])
                metodo = request.form['metodo_pago']

                cursor.execute("""
                    INSERT INTO pagos (id_cliente,id_membresia,monto,metodo_pago)
                    VALUES (%s,%s,%s,%s)
                """, (id_cliente, id_memb, monto, metodo))
                id_pago = cursor.lastrowid
                conn.commit()

                # Registrar ingreso en finanzas (si está asociado a una membresía)
                cursor.execute("SELECT nombre, apellido FROM clientes WHERE id_cliente=%s", (id_cliente,))
                cli = cursor.fetchone() or {'nombre':'Cliente','apellido':''}
                frecuencia = 'general'
                nombre_tipo = 'N/A'
                if id_memb:
                    cursor.execute("""
                        SELECT t.nombre, t.duracion_dias
                          FROM membresias m
                          JOIN tipos_membresia t ON m.id_tipo_membresia=t.id_tipo_membresia
                         WHERE m.id_membresia=%s
                    """, (id_memb,))
                    tipo = cursor.fetchone()
                    if tipo:
                        d = int(tipo['duracion_dias']) if tipo['duracion_dias'] is not None else None
                        if d is None:
                            frecuencia = 'personalizada'
                        elif d <= 1:
                            frecuencia = 'por día'
                        elif d == 15:
                            frecuencia = 'quincenal'
                        elif 28 <= d <= 31:
                            frecuencia = 'mensual'
                        else:
                            frecuencia = f"{d} días"
                        nombre_tipo = tipo['nombre']

                descripcion = f"Pago de membresía {nombre_tipo} ({frecuencia}) - {cli['nombre']} {cli['apellido']}"
                origen = f"membresía {frecuencia}" if id_memb else "pago"
                cursor.execute("""
                    INSERT INTO finanzas(descripcion, monto, tipo, origen, fecha)
                    VALUES (%s,%s,'ingreso',%s,NOW())
                """, (descripcion, monto, origen))
                conn.commit()

                flash("Pago registrado con éxito ✅", "success")
                return redirect(url_for('factura_pago', id_pago=id_pago))
        except Exception as e:
            flash(f"Error: {e}", "danger")
            return redirect(url_for('obtener_pagos'))
        finally:
            if conn: conn.close()

    conn = obtener_conexion()
    with conn.cursor() as cursor:
        cursor.execute("SELECT id_cliente,nombre,apellido FROM clientes")
        clientes = cursor.fetchall()

        cursor.execute("""
            SELECT
              m.id_membresia,
              t.nombre AS tipo_membresia,
              m.fecha_inicio,
              m.fecha_fin
            FROM membresias m
            JOIN tipos_membresia t ON m.id_tipo_membresia=t.id_tipo_membresia
            WHERE m.fecha_fin>=CURRENT_DATE()
        """)
        membresias = cursor.fetchall()
    conn.close()

    return render_template('nuevo_pago.html', clientes=clientes, membresias=membresias)


# ------------------ ELIMINAR PAGO ------------------
@app.route('/pagos/eliminar/<int:id>', methods=['POST'])
def eliminar_pago(id):
    try:
        conn = obtener_conexion()
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM pagos WHERE id_pago=%s", (id,))
            conn.commit()
            flash("Pago eliminado con éxito", "success")
            return redirect(url_for('obtener_pagos'))
    except Exception as e:
        flash(f"Error: {e}", "danger")
        return redirect(url_for('obtener_pagos'))
    finally:
        if conn: conn.close()


# -------- RUTAS PARA PRODUCTOS --------
# =================== PRODUCTOS ===================


 
# =================== VENTAS ===================

# ----------------------------
# RUTINAS PERSONALIZADAS
# ----------------------------
# LISTADO
@app.route("/rutinas")
def rutinas():
    conn = obtener_conexion()
    rutinas = []
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT r.id_rutina, r.titulo, r.descripcion,
                       r.fecha_inicio, r.fecha_fin,
                       c.id_cliente, c.nombre AS cliente_nombre, c.apellido AS cliente_apellido,
                       e.id_entrenador, e.nombre AS entrenador_nombre, e.apellido AS entrenador_apellido
                FROM rutinas_personalizadas r
                JOIN clientes c ON r.id_cliente = c.id_cliente
                JOIN entrenadores e ON r.id_entrenador = e.id_entrenador
                ORDER BY r.creado_en DESC
            """)
            rutinas = cur.fetchall()
    finally:
        conn.close()
    return render_template("rutinas.html", rutinas=rutinas)


# NUEVA
@app.route("/rutinas/nueva", methods=["GET", "POST"])
def rutinas_nueva():
    conn = obtener_conexion()
    try:
        if request.method == "POST":
            titulo = request.form["titulo"]
            descripcion = request.form.get("descripcion")
            id_cliente = request.form["id_cliente"]
            id_entrenador = request.form["id_entrenador"]
            fecha_inicio = request.form["fecha_inicio"]

            fi = datetime.strptime(fecha_inicio, "%Y-%m-%d").date()
            fecha_fin = fi + timedelta(days=29)

            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO rutinas_personalizadas
                      (titulo, descripcion, id_cliente, id_entrenador, fecha_inicio, fecha_fin, duracion_dias)
                    VALUES (%s,%s,%s,%s,%s,%s,%s)
                """, (titulo, descripcion, id_cliente, id_entrenador, fecha_inicio, fecha_fin, 30))
                id_rutina = cur.lastrowid

                # Horarios de lunes a sábado
                dias = ["Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"]
                for d in dias:
                    hora = request.form.get(f"hora_{d}") or None
                    ejercicios = request.form.get(f"ej_{d}") or None
                    if hora or ejercicios:
                        cur.execute("""
                            INSERT INTO rutina_horarios (id_rutina, dia_semana, hora_programada, ejercicios)
                            VALUES (%s,%s,%s,%s)
                        """, (id_rutina, d, hora, ejercicios))
            conn.commit()
            flash("Rutina creada correctamente", "success")
            return redirect(url_for("rutinas"))
        else:
            with conn.cursor() as cur:
                cur.execute("SELECT * FROM clientes ORDER BY nombre")
                clientes = cur.fetchall()
                cur.execute("SELECT * FROM entrenadores ORDER BY nombre")
                entrenadores = cur.fetchall()
            return render_template("nueva_rutina.html", clientes=clientes, entrenadores=entrenadores)
    finally:
        conn.close()


# VER DETALLE
@app.route("/rutinas/<int:id_rutina>")
def rutinas_ver(id_rutina):
    conn = obtener_conexion()
    rutina, horarios, asistencias_dict = None, [], {}
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT r.*, c.id_cliente, c.nombre AS cliente_nombre, c.apellido AS cliente_apellido,
                       e.nombre AS entrenador_nombre, e.apellido AS entrenador_apellido
                FROM rutinas_personalizadas r
                JOIN clientes c ON r.id_cliente = c.id_cliente
                JOIN entrenadores e ON r.id_entrenador = e.id_entrenador
                WHERE r.id_rutina=%s
            """, (id_rutina,))
            rutina = cur.fetchone()

            if not rutina:
                flash("Rutina no encontrada", "danger")
                return redirect(url_for("rutinas"))

            cur.execute("SELECT * FROM rutina_horarios WHERE id_rutina=%s", (id_rutina,))
            horarios = cur.fetchall()

            cur.execute("SELECT * FROM asistencia_rutina WHERE id_rutina=%s", (id_rutina,))
            asistencias = cur.fetchall()
            asistencias_dict = {a["fecha"].isoformat(): a for a in asistencias}
    finally:
        conn.close()

    # Generar lista de fechas (lunes a sábado) para el mes
    fechas = []
    fecha = rutina["fecha_inicio"]
    while fecha <= rutina["fecha_fin"]:
        if fecha.weekday() < 6:  # lunes=0 .. sábado=5
            fechas.append(fecha)
        fecha += timedelta(days=1)

    return render_template("ver_rutina.html",
                           rutina=rutina,
                           horarios=horarios,
                           asistencias_dict=asistencias_dict,
                           fechas=fechas,
                           datetime=datetime)


# EDITAR
@app.route("/rutinas/editar/<int:id_rutina>", methods=["GET", "POST"])
def rutinas_editar(id_rutina):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cur:
            if request.method == "POST":
                titulo = request.form["titulo"]
                descripcion = request.form.get("descripcion")
                id_cliente = request.form["id_cliente"]
                id_entrenador = request.form["id_entrenador"]
                fecha_inicio = request.form["fecha_inicio"]

                fi = datetime.strptime(fecha_inicio, "%Y-%m-%d").date()
                fecha_fin = fi + timedelta(days=29)

                cur.execute("""
                    UPDATE rutinas_personalizadas
                    SET titulo=%s, descripcion=%s, id_cliente=%s, id_entrenador=%s,
                        fecha_inicio=%s, fecha_fin=%s, duracion_dias=%s
                    WHERE id_rutina=%s
                """, (titulo, descripcion, id_cliente, id_entrenador, fecha_inicio, fecha_fin, 30, id_rutina))

                cur.execute("DELETE FROM rutina_horarios WHERE id_rutina=%s", (id_rutina,))
                dias = ["Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"]
                for d in dias:
                    hora = request.form.get(f"hora_{d}") or None
                    ejercicios = request.form.get(f"ej_{d}") or None
                    if hora or ejercicios:
                        cur.execute("""
                            INSERT INTO rutina_horarios (id_rutina, dia_semana, hora_programada, ejercicios)
                            VALUES (%s,%s,%s,%s)
                        """, (id_rutina, d, hora, ejercicios))
                conn.commit()
                flash("Rutina actualizada", "success")
                return redirect(url_for("rutinas_ver", id_rutina=id_rutina))
            else:
                cur.execute("SELECT * FROM rutinas_personalizadas WHERE id_rutina=%s", (id_rutina,))
                rutina = cur.fetchone()
                cur.execute("SELECT * FROM clientes ORDER BY nombre")
                clientes = cur.fetchall()
                cur.execute("SELECT * FROM entrenadores ORDER BY nombre")
                entrenadores = cur.fetchall()
                cur.execute("SELECT * FROM rutina_horarios WHERE id_rutina=%s", (id_rutina,))
                horarios = cur.fetchall()
                return render_template("editar_rutina.html",
                                       rutina=rutina, clientes=clientes,
                                       entrenadores=entrenadores, horarios=horarios)
    finally:
        conn.close()


# ELIMINAR
@app.route("/rutinas/eliminar/<int:id_rutina>")
def rutinas_eliminar(id_rutina):
    conn = obtener_conexion()
    try:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM rutinas_personalizadas WHERE id_rutina=%s", (id_rutina,))
        conn.commit()
        flash("Rutina eliminada", "success")
    finally:
        conn.close()
    return redirect(url_for("rutinas"))


# ASISTENCIA (JSON)
@app.route("/rutinas/marcar_asistencia", methods=["POST"])
def rutinas_marcar_asistencia():
    data = request.get_json()
    id_rutina = data.get("id_rutina")
    fecha = data.get("fecha")
    dia_semana = data.get("dia_semana")
    presente = data.get("presente", 0)
    hora = data.get("hora_realizacion")

    conn = obtener_conexion()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT id_asistencia FROM asistencia_rutina WHERE id_rutina=%s AND fecha=%s",
                        (id_rutina, fecha))
            existe = cur.fetchone()
            if existe:
                cur.execute("""
                    UPDATE asistencia_rutina
                    SET presente=%s, hora_realizada=%s, dia_semana=%s
                    WHERE id_asistencia=%s
                """, (presente, hora, dia_semana, existe["id_asistencia"]))
            else:
                cur.execute("""
                    INSERT INTO asistencia_rutina (id_rutina, fecha, dia_semana, hora_realizada, presente)
                    VALUES (%s,%s,%s,%s,%s)
                """, (id_rutina, fecha, dia_semana, hora, presente))
        conn.commit()
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})
    finally:
        conn.close()

    return jsonify({"status": "ok"})



@app.route('/membresias/proximas_vencer')
def proximas_membresias_vencer():
    conn = obtener_conexion()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT
                    m.id_membresia,
                    c.nombre,
                    c.apellido,
                    t.nombre AS tipo_membresia,
                    m.fecha_fin
                FROM membresias m
                JOIN clientes c ON m.id_cliente = c.id_cliente
                LEFT JOIN tipos_membresia t ON m.id_tipo_membresia = t.id_tipo_membresia
                WHERE m.fecha_fin BETWEEN CURRENT_DATE() AND DATE_ADD(CURRENT_DATE(), INTERVAL 30 DAY)
                ORDER BY m.fecha_fin ASC
            """)
            membresias = cursor.fetchall()
        return render_template('proximas_membresias_vencer.html', membresias=membresias)
    finally:
        conn.close()

# -------- RUTAS PARA LOGIN, REGISTRO Y RECUPERACIÓN --------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        usuario = request.form['usuario']
        password = request.form['password']
        conn = obtener_conexion()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM usuarios WHERE usuario=%s AND password=%s", (usuario, password))
                user = cursor.fetchone()
                if user:
                    session['usuario'] = usuario
                    flash('Bienvenido, sesión iniciada correctamente', 'success')
                    return redirect(url_for('index'))
                else:
                    flash('Usuario o contraseña incorrectos', 'danger')
        finally:
            conn.close()
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('usuario', None)
    flash('Sesión cerrada', 'info')
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        usuario = request.form['usuario']
        email = request.form['email']
        password = request.form['password']
        conn = obtener_conexion()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM usuarios WHERE usuario=%s OR email=%s", (usuario, email))
                existe = cursor.fetchone()
                if existe:
                    flash('El usuario o correo ya existe', 'danger')
                else:
                    cursor.execute("INSERT INTO usuarios (usuario, email, password) VALUES (%s, %s, %s)", (usuario, email, password))
                    conn.commit()
                    flash('Cuenta creada correctamente, ahora puedes iniciar sesión', 'success')
                    return redirect(url_for('login'))
        finally:
            conn.close()
    return render_template('register.html')

@app.route('/forgot', methods=['GET', 'POST'])
def forgot():
    if request.method == 'POST':
        email = request.form['email']
        conn = obtener_conexion()
        try:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM usuarios WHERE email=%s", (email,))
                user = cursor.fetchone()
                if user:
                    # Simula envío de correo con código temporal
                    temp_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
                    session['reset_email'] = email
                    session['reset_code'] = temp_code
                    flash(f'Se ha enviado un código de recuperación a tu correo: {temp_code}', 'info')
                    return redirect(url_for('reset_password'))
                else:
                    flash('Correo no encontrado', 'danger')
        finally:
            conn.close()
    return render_template('forgot.html')

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'POST':
        code = request.form['code']
        password = request.form['password']
        if code == session.get('reset_code'):
            email = session.get('reset_email')
            conn = obtener_conexion()
            try:
                with conn.cursor() as cursor:
                    cursor.execute("UPDATE usuarios SET password=%s WHERE email=%s", (password, email))
                    conn.commit()
                    flash('Contraseña restablecida correctamente', 'success')
                    session.pop('reset_email', None)
                    session.pop('reset_code', None)
                    return redirect(url_for('login'))
            finally:
                conn.close()
        else:
            flash('Código incorrecto', 'danger')
    return render_template('reset_password.html')

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
