function formatCop(value) {
  if (value === null || value === undefined) return '';
  const digits = String(value).replace(/[^0-9]/g, '');
  if (!digits) return '';
  const n = parseInt(digits, 10);
  try {
    return 'COP $' + n.toLocaleString('es-CO');
  } catch (e) {
    // Fallback si toLocaleString falla
    return 'COP $' + digits.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  }
}

function initCopInputs() {
  const inputs = document.querySelectorAll('.money-input');
  inputs.forEach((input) => {
    // Formatear valor inicial si lo hay
    if (input.value) {
      input.value = formatCop(input.value);
    }

    input.addEventListener('input', () => {
      input.value = formatCop(input.value);
    });

    input.addEventListener('blur', () => {
      input.value = formatCop(input.value);
    });
  });
}

// Auto-init si se carga este script después del DOM
document.addEventListener('DOMContentLoaded', () => {
  if (typeof initCopInputs === 'function') {
    initCopInputs();
  }
});