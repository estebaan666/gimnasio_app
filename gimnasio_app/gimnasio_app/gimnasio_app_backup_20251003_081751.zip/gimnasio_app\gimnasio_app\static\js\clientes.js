document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById("searchInput");
    const clickablePhotos = document.querySelectorAll('.js-open-cliente');

    /* 🔎 Filtro de búsqueda */
    if (searchInput) {
        searchInput.addEventListener("keyup", function() {
            const filter = this.value.toLowerCase();
            const cards = document.querySelectorAll("#clientCards .client-card");
            cards.forEach(card => {
                const name = card.dataset.nombre.toLowerCase();
                card.style.display = name.includes(filter) ? "flex" : "none";
            });
        });
    }

    /* 👆 Abrir modal desde data-cliente sin inline JS */
    clickablePhotos.forEach(el => {
        el.addEventListener('click', () => {
            const json = el.getAttribute('data-cliente');
            try {
                const cliente = JSON.parse(json);
                showDetails(cliente);
            } catch (e) {
                console.error('No se pudo leer datos del cliente', e);
            }
        });
    });
});

/* 📌 Mostrar modal con datos */
function showDetails(cliente) {
    document.getElementById("modalNombre").textContent = cliente.nombre + " " + cliente.apellido;
    document.getElementById("modalIdentificacion").textContent = cliente.identificacion || "N/D";
    document.getElementById("modalGenero").textContent = cliente.genero || "N/D";
    document.getElementById("modalNacimiento").textContent = cliente.fecha_nacimiento || "N/D";
    document.getElementById("modalTelefono").textContent = cliente.telefono || "N/D";
    document.getElementById("modalEmail").textContent = cliente.email || "N/D";
    document.getElementById("modalDireccion").textContent = cliente.direccion || "N/D";
    document.getElementById("modalEnfermedades").textContent = cliente.enfermedades || "N/D";
    document.getElementById("modalAlergias").textContent = cliente.alergias || "N/D";
    document.getElementById("modalFracturas").textContent = cliente.fracturas || "N/D";
    document.getElementById("modalObservaciones").textContent = cliente.observaciones_medicas || "N/D";

    // 📸 Foto con fallback
    document.getElementById("modalFoto").src = cliente.foto_url || "/static/img/default-user.png";

    const modal = document.getElementById("clientModal");
    modal.dataset.clienteId = cliente.id_cliente;
    modal.style.display = "flex";

    // Animación
    const modalContent = modal.querySelector(".modal-content");
    modalContent.style.animation = "none";
    modalContent.offsetHeight;
    modalContent.style.animation = "zoomIn 0.4s ease forwards";
}

/* ❌ Cerrar modal */
function closeModal() {
    document.getElementById("clientModal").style.display = "none";
}

/* ✏️ Editar cliente */
function editClient() {
    const id = document.getElementById("clientModal").dataset.clienteId;
    if (id) {
        window.location.href = `/clientes/editar/${id}`;
    }
}

/* 🗑️ Eliminar cliente */
function deleteClient() {
    const id = document.getElementById("clientModal").dataset.clienteId;
    if (id && confirm("¿Seguro que quieres eliminar este cliente?")) {
        fetch(`/clientes/eliminar/${id}`, {
            method: "POST"
        }).then(() => {
            window.location.reload();
        }).catch(err => alert("Error al eliminar cliente: " + err));
    }
}

/* Exponer funciones al HTML */
window.showDetails = showDetails;
window.closeModal = closeModal;
window.editClient = editClient;
window.deleteClient = deleteClient;
